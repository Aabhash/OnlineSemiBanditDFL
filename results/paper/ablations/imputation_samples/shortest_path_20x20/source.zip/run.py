import json, platform, subprocess, sys, time, zipfile
from pathlib import Path

import jax
import numpy as np
import optax

OUTPUT = Path(__file__).resolve().parent
REPO = OUTPUT.parents[2]
sys.path.insert(0, str(REPO))

from experiments.ablations.common import make_co_solver
from experiments.tuning.objectives import create_agent_from_params
from src.agents.base import run_agent_on_episode
from src.envs import create_env


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def load_episode(config, seed):
    root = REPO / config["episode_source"] / "seeds" / f"seed_{seed}" / "datasets" / config["dataset"]
    with np.load(root / "episode.npz", allow_pickle=False) as saved:
        arrays = {key: saved[key] for key in (
            "context", "true_values", "optimal_action", "optimal_value",
            "mean_values", "mean_optimal_action", "mean_optimal_value"
        )}
    return {
        "minimize": True,
        "rounds_data": [{key: values[t] for key, values in arrays.items()}
                        for t in range(config["rounds"])],
    }


def main():
    config = json.loads((OUTPUT / "config.json").read_text())
    if (OUTPUT / "runtime.json").exists():
        raise RuntimeError("This run already started; use a new directory for another execution.")
    if jax.default_backend() != "cpu":
        raise RuntimeError("This reproduction uses CPU.")
    runtime = {
        "python": platform.python_version(), "jax": jax.__version__,
        "numpy": np.__version__, "optax": optax.__version__,
        "jax_x64": jax.config.jax_enable_x64,
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
    }
    write_json(OUTPUT / "runtime.json", runtime)
    with zipfile.ZipFile(OUTPUT / "source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        paths = {Path(module.__file__).resolve() for module in sys.modules.values()
                 if getattr(module, "__file__", None)}
        for path in sorted(paths):
            if path.is_relative_to(REPO / "src") or path.is_relative_to(REPO / "experiments"):
                archive.write(path, path.relative_to(REPO))
        archive.write(__file__, "run.py")
        archive.write(OUTPUT / "config.json", "config.json")

    table2 = json.loads((REPO / config["table2_source"]).read_text())
    reference = table2[f"BayesianSPO_{config['dataset']}_semi_bandit"]
    rows = []
    for samples in config["m_values"]:
        for index, seed in enumerate(config["seeds"]):
            cell = OUTPUT / f"M{samples}" / f"seed_{seed}"
            cell.mkdir(parents=True)
            env = create_env(config["dataset"], seed=seed, **config["environment"])
            params = {**config["agent_params"], "imputation_samples": samples}
            agent = create_agent_from_params("BayesianSPO", env, params, seed,
                                             config["rounds"], lr=config["update_lr"])
            episode = load_episode(config, seed)
            progress = {"M": samples, "seed": seed, "round": 0, "completed_runs": len(rows)}
            write_json(OUTPUT / "progress.json", progress)
            update = agent.update
            started = time.monotonic()

            def updating(*args, **kwargs):
                result = update(*args, **kwargs)
                progress["round"] += 1
                if progress["round"] % 1000 == 0:
                    write_json(OUTPUT / "progress.json", progress)
                    print(f"M={samples} seed={seed} {progress['round']}/{config['rounds']}"
                          f" elapsed={time.monotonic() - started:.1f}s", flush=True)
                return result

            agent.update = updating
            result = run_agent_on_episode(
                agent, episode, config["rounds"], lr=config["update_lr"], full_feedback=False,
                diagnostics=config["diagnostics"], diagnostics_interval=config["diagnostics_interval"],
                co_solver=make_co_solver(env),
            )
            row = {
                "M": samples, "seed": seed, "rounds": config["rounds"], "params": params,
                "final_regret": float(result["final_regret"]),
                "final_pseudo_regret": float(result["final_pseudo_regret"]),
                "seconds": time.monotonic() - started,
                "table2_regret": reference["cumulative_regrets"][index],
                "difference_from_table2": float(result["final_regret"]) - reference["cumulative_regrets"][index],
            }
            np.savez_compressed(cell / "trajectory.npz",
                **{key: np.asarray(result[key]) for key in (
                    "regrets", "cumulative_regret", "pseudo_regrets", "cumulative_pseudo_regret",
                    "overall_mae", "contested_mae", "noncontested_mae", "diagnostic_rounds"
                )})
            write_json(cell / "result.json", row)
            rows.append(row)
            print(f"DONE M={samples} seed={seed} regret={row['final_regret']:.9f}"
                  f" Table2_delta={row['difference_from_table2']:+.9f}", flush=True)
        values = np.array([row["final_regret"] for row in rows if row["M"] == samples])
        print(f"SUMMARY M={samples} n={len(values)} mean={values.mean():.9f}"
              f" sd={values.std(ddof=1):.9f}", flush=True)
        write_json(OUTPUT / "results.json", {"config": config, "runs": rows})
    write_json(OUTPUT / "progress.json", {"status": "complete", "completed_runs": len(rows)})


if __name__ == "__main__":
    main()
